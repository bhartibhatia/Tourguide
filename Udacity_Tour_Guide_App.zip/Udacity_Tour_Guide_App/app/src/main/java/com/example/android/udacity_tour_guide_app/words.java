package com.example.android.udacity_tour_guide_app;

public class words {
    private int mplacename;
    private int mplaceaddress;
    private int mmobileno;
    private int mtiming;
    private int mImageResourceId;

    public words(int placename, int placeaddress, int mobileno, int timing) {
        mplacename = placename;
        mplaceaddress = placeaddress;
        mmobileno = mobileno;
        mtiming = timing;
    }

    public words(int placename, int placeaddress, int mobileno, int timing, int imageresourcsid) {
        mplacename = placename;
        mplaceaddress = placeaddress;
        mmobileno = mobileno;
        mtiming = timing;
        mImageResourceId = imageresourcsid;
    }

    public int getMplacename() {
        return mplacename;
    }

    public int getMplaceaddress() {
        return mplaceaddress;
    }

    public int getMmobileno() {
        return mmobileno;
    }

    public int getMtiming() {
        return mtiming;
    }

    public int getmImageResourceId() {
        return mImageResourceId;
    }
}
