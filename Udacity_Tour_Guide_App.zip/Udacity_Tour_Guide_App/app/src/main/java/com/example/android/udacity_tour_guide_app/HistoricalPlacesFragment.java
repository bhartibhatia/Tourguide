package com.example.android.udacity_tour_guide_app;

import android.content.Context;
import android.media.AudioManager;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import java.util.ArrayList;

public class HistoricalPlacesFragment extends Fragment {
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.word_list, container, false);

        final ArrayList<words> word = new ArrayList<words>();
        word.add(new words(R.string.his_one, R.string.his_one_address, R.string.his_one_phone, R.string.his_one_time, R.drawable.amertwo));
        word.add(new words(R.string.his_two, R.string.his_two_address, R.string.his_one_phone, R.string.his_one_time, R.drawable.alberthall));
        word.add(new words(R.string.his_three, R.string.his_three_address, R.string.his_three_phone, R.string.his_three_time, R.drawable.jaigarh));
        word.add(new words(R.string.his_four, R.string.his_four_address, R.string.his_four_phone, R.string.his_four_time, R.drawable.jantarmantar));
        word.add(new words(R.string.his_five, R.string.his_five_address, R.string.his_five_phone, R.string.his_five_time, R.drawable.jalmahal));
        word.add(new words(R.string.his_six, R.string.his_six_address, R.string.his_six_phone, R.string.his_six_time, R.drawable.govinddevji));
        word.add(new words(R.string.his_seven, R.string.his_seven_address, R.string.his_seven_phone, R.string.his_seven_time, R.drawable.citypalace));
        word.add(new words(R.string.his_eight, R.string.his_eight_address, R.string.his_eight_phone, R.string.his_eight_time, R.drawable.birlamandir));
        word.add(new words(R.string.his_nine, R.string.his_nine_address, R.string.his_nine_phone, R.string.his_nine_time, R.drawable.hawamahal));
        word.add(new words(R.string.his_ten, R.string.his_ten_address, R.string.his_ten_phone, R.string.his_ten_time, R.drawable.chokhidhani));

        WordAdapter adapter = new WordAdapter(getActivity(), word, R.color.category_historical_place);

        ListView listView = (ListView) rootView.findViewById(R.id.list);
        listView.setAdapter(adapter);
        return rootView;
    }
}

