package com.example.android.udacity_tour_guide_app;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import java.util.ArrayList;

public class ShoppingMallFragment extends Fragment {
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.word_list, container, false);

        final ArrayList<words> word = new ArrayList<words>();
        word.add(new words(R.string.shop_one, R.string.shop_one_address, R.string.shop_one_phone, R.string.shop_one_time, R.drawable.apexmall));
        word.add(new words(R.string.shop_two, R.string.shop_two_address, R.string.shop_one_phone, R.string.shop_one_time, R.drawable.citypulse));
        word.add(new words(R.string.shop_three, R.string.shop_three_address, R.string.shop_three_phone, R.string.shop_one_time, R.drawable.crystalcourt));
        word.add(new words(R.string.shop_four, R.string.shop_four_address, R.string.shop_four_phone, R.string.shop_one_time, R.drawable.gauravtower));
        word.add(new words(R.string.shop_five, R.string.shop_five_address, R.string.shop_five_phone, R.string.shop_one_time, R.drawable.mgf));
        word.add(new words(R.string.shop_six, R.string.shop_six_address, R.string.shop_six_phone, R.string.shop_one_time, R.drawable.sarogimansion));
        word.add(new words(R.string.shop_seven, R.string.shop_seven_address, R.string.shop_seven_phone, R.string.shop_one_time, R.drawable.pinksquare));
        word.add(new words(R.string.shop_eight, R.string.shop_eight_address, R.string.shop_eight_phone, R.string.shop_one_time, R.drawable.wtp));
        word.add(new words(R.string.shop_nine, R.string.shop_nine_address, R.string.shop_nine_phone, R.string.shop_one_time, R.drawable.triton));
        word.add(new words(R.string.shop_ten, R.string.shop_ten_address, R.string.shop_ten_phone, R.string.shop_one_time, R.drawable.tripolia));

        WordAdapter adapter = new WordAdapter(getActivity(), word, R.color.category_shopping_place);

        ListView listView = (ListView) rootView.findViewById(R.id.list);
        listView.setAdapter(adapter);
        return rootView;
    }
}
