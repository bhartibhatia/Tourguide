package com.example.android.udacity_tour_guide_app;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import java.util.ArrayList;

public class ResortsFragment extends Fragment {
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.word_list, container, false);

        final ArrayList<words> word = new ArrayList<words>();
        word.add(new words(R.string.resort_one, R.string.resort_one_address, R.string.resort_one_phone, R.string.resort_one_time, R.drawable.bykegrass));
        word.add(new words(R.string.resort_two, R.string.resort_two_address, R.string.resort_one_phone, R.string.resort_one_time, R.drawable.heiwaheaven));
        word.add(new words(R.string.resort_three, R.string.resort_three_address, R.string.resort_three_phone, R.string.resort_one_time, R.drawable.kanchankesari));
        word.add(new words(R.string.resort_four, R.string.resort_four_address, R.string.resort_four_phone, R.string.resort_one_time, R.drawable.heritagevillage));
        word.add(new words(R.string.resort_five, R.string.resort_five_address, R.string.resort_five_phone, R.string.resort_one_time, R.drawable.nakhralorajasthan));
        word.add(new words(R.string.resort_six, R.string.resort_six_address, R.string.resort_six_phone, R.string.resort_one_time, R.drawable.sunriseresort));
        word.add(new words(R.string.resort_seven, R.string.resort_seven_address, R.string.resort_seven_phone, R.string.resort_one_time, R.drawable.treehouse));
        word.add(new words(R.string.resort_eight, R.string.resort_eight_address, R.string.resort_eight_phone, R.string.resort_one_time, R.drawable.apanorajasthan));
        word.add(new words(R.string.resort_nine, R.string.resort_nine_address, R.string.resort_nine_phone, R.string.resort_one_time, R.drawable.jaimahal));
        word.add(new words(R.string.resort_ten, R.string.resort_ten_address, R.string.resort_ten_phone, R.string.resort_one_time, R.drawable.chokhidhanitwo));

        WordAdapter adapter = new WordAdapter(getActivity(), word, R.color.category_resort);

        ListView listView = (ListView) rootView.findViewById(R.id.list);
        listView.setAdapter(adapter);
        return rootView;
    }
}
