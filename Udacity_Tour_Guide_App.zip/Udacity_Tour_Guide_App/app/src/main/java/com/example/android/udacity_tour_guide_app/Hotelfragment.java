package com.example.android.udacity_tour_guide_app;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import java.util.ArrayList;

public class Hotelfragment extends Fragment {
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.word_list, container, false);

        final ArrayList<words> word = new ArrayList<words>();
        word.add(new words(R.string.hotel_one, R.string.hotel_one_address, R.string.hotel_one_phone, R.string.hotel_one_time, R.drawable.holidayinn));
        word.add(new words(R.string.hotel_two, R.string.hotel_two_address, R.string.hotel_one_phone, R.string.hotel_one_time, R.drawable.rajputana));
        word.add(new words(R.string.hotel_three, R.string.hotel_three_address, R.string.hotel_three_phone, R.string.hotel_one_time, R.drawable.lemeridien));
        word.add(new words(R.string.hotel_four, R.string.hotel_four_address, R.string.hotel_four_phone, R.string.hotel_one_time, R.drawable.lordsplaza));
        word.add(new words(R.string.hotel_five, R.string.hotel_five_address, R.string.hotel_five_phone, R.string.hotel_one_time, R.drawable.marriott));
        word.add(new words(R.string.hotel_six, R.string.hotel_six_address, R.string.hotel_six_phone, R.string.hotel_one_time, R.drawable.ramada));
        word.add(new words(R.string.hotel_seven, R.string.hotel_seven_address, R.string.hotel_seven_phone, R.string.hotel_one_time, R.drawable.umaid));
        word.add(new words(R.string.hotel_eight, R.string.hotel_eight_address, R.string.hotel_eight_phone, R.string.hotel_one_time, R.drawable.tridnet));
        word.add(new words(R.string.hotel_nine, R.string.hotel_nine_address, R.string.hotel_nine_phone, R.string.hotel_one_time, R.drawable.rajvilas));
        word.add(new words(R.string.hotel_ten, R.string.hotel_ten_address, R.string.hotel_ten_phone, R.string.hotel_one_time, R.drawable.samode));

        WordAdapter adapter = new WordAdapter(getActivity(), word, R.color.category_hotels);

        ListView listView = (ListView) rootView.findViewById(R.id.list);
        listView.setAdapter(adapter);
        return rootView;
    }
}
